Fast Sensitivities using AAD and GPUs


